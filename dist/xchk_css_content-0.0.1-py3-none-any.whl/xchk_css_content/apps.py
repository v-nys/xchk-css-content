from django.apps import AppConfig


class CSScontentConfig(AppConfig):
    name = 'xchk_css_content'
